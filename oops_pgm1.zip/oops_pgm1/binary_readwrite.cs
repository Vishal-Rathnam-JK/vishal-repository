﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace oops_pgm1
{
    class binary_readwrite
    {
        //public static void Main()
        //{
        //    FileStream fs1 = new FileStream(@"D:\Vishal\demo2.txt", FileMode.Open, FileAccess.ReadWrite);
        //    FileStream fs2 = new FileStream(@"D:\Vishal\binout.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
        //    BinaryReader br = new BinaryReader(fs1);
        //    StreamWriter sw = new StreamWriter(fs2);
        //    string name = br.ReadString();
        //    int age = br.ReadInt32();
        //    string des = br.ReadString();
        //    br.Close();
        //    sw.WriteLine(name);
        //    sw.WriteLine(age);
        //    sw.WriteLine(des);
        //    sw.Close();
            
            
            //string ename = "vishal";
            //int age = 22;
            //string designation = "Legend";            
            //bw.Write(ename);            
            //bw.Write(age);
            //bw.Write(designation);
            //bw.Close();

        //}
    }
}
