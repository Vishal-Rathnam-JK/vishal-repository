﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{    
    delegate void winprize();
    //This is the publisher class
    class delegate_with_event
    {
        static int count;
        public event winprize valuableuser;
        public event winprize firstuser;
        public void purchase()
        {
            count++;
            Console.WriteLine("Thanks for purchasing the product");

            if (count%3==0)
            {
                valuableuser.Invoke();     //Raise the event
            }
            else if (count==1)
            {
                firstuser.Invoke();
            }
        }
    }
    //This is the subscriber class
    class shoppingcart
    {
        public static void greeting()
        {
            Console.WriteLine("You are the valuable customer");
        }
        public static void first()
        {
            Console.WriteLine("Congratulations !!! you are the first visitor for the day");
        }
        //public static void Main()
        //{
        //    int choice;
        //    delegate_with_event de = new delegate_with_event();
        //    de.valuableuser +=new winprize(greeting);
        //    de.firstuser += new winprize(first);
        //    do
        //    {
        //        de.purchase();
        //        Console.WriteLine("Do you want to continue?\n1.Yes\n2.No");
        //        choice = int.Parse(Console.ReadLine());
        //    } while (choice==1);
        //}
    }
}
