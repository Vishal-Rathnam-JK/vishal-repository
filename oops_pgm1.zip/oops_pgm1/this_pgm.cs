﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class this_pgm
    {
        public int sid;
        public string sname;
        public void accept(int sid,string sname)
        {
           this.sid =sid;
            this.sname = sname;
        }
        public void display()
        {
            Console.WriteLine("student id is{0}, name is {1}",sid,sname);
        }
        //public static void Main()
        //{
        //    this_pgm t = new this_pgm();
        //    t.accept(1, "vishal");
        //    t.display();         
        //}
    }
}
