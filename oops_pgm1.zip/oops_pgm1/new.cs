﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    //class one
    //{
    //    public int a;
    //    private int b;
    //    protected int c;
    //}
    //class two:one
    //{
    //    public int x;
    //    private int y;
    //    protected int z;
    //}
    //class three:two
    //{
    //    public int i;
    //    private int j;
    //    protected int k;
    //    //public static void Main()
    //    //{
    //    //    three th = new three();
    //    //    two tw = new two();
            
    //    //}
    //}

}
