﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace oops_pgm1
{
    class Hash_Table
    {
        //public static void Main()
        //{
        //    Hashtable ht = new Hashtable();
        //    ht.Add("hi", "welcome");
        //    ht.Add(621737, "vishal");
        //    ht.Add("vishal", "ECE");
        //    ht.Add(null, "Duplicate");
            //IDictionaryEnumerator(ht);
            //Console.WriteLine(ht.Count);
            //Console.WriteLine(ht.ContainsKey("hi"));
            //Console.WriteLine(ht.ContainsValue("vishal"));
            //Console.WriteLine(ht[621737]);
            //ICollection ic = ht.Keys;
            //foreach (var item in ic)
            //{
            //    Console.WriteLine("key is {0} , value is {1} ", item, ht[item]);
            //}


        //}
    }
}
