﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class Generic_example
    {
        public void show<T>(T data)
        {
            Console.WriteLine("the value is "+data);
        }
        //public static void Main()
        //{
        //    Generic_example ge = new Generic_example();
        //    ge.show("ranga");
        //    ge.show(4536);
        //    ge.show("kaatu manidhan");
        //    ge.show(true);
        //    ge.show(2335.52525);
        //    ge.show(24214 + 52355.23523);
        //}
    }
}
