﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class prop
    {
        private string color = "black";        
        public string COLOR     
        {
            get
            {
                return color;
            }
            set
            {
                color = value;
            }
        }
    }
    class call
    {
        //public static void Main()
        //{
        //    prop p = new prop();
        //    Console.WriteLine(p.COLOR);
        //    p.COLOR = "red";
        //    Console.WriteLine(p.COLOR);
            
        //}
    }
}
