﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{

    //class Exception_handling
    //{
    //    public static void Main()
    //    {
    //        int x = 0, y = 0, z = 0;
            
    //        try
    //        {

    //            Console.WriteLine("enter the value of x:");
    //            x = int.Parse(Console.ReadLine());
    //            Console.WriteLine("enter the value of y:");
    //            y = int.Parse(Console.ReadLine());
    //            z = x / y;
    //            Console.WriteLine("the output is " + z);
    //        }
    //        catch (DivideByZeroException e)
    //        {

    //            Console.WriteLine("do not divide by zero");
    //            Console.WriteLine(e.Message);     // this is the system defined message
    //            //Console.WriteLine(e.TargetSite);
    //            //Console.WriteLine(e.StackTrace);
    //            //Console.WriteLine(e.HelpLink);
    //            //Console.WriteLine(e.Source);
    //            // throw;    //throws all the messages.
    //        }
    //        catch (FormatException f)
    //        {
    //            Console.WriteLine("enter only numbers");
    //        }
    //        catch (Exception r)
    //        {
    //            Console.WriteLine(r.Message);
    //        }
    //        finally
    //        {
    //            Console.WriteLine("Thanks");
    //        }
    //    }
   // }
}
