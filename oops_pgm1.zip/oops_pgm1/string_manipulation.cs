﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class string_manipulation
    {
//        public static void Main()
//        {
//            string fname = "ranga";
//            string lname = "grylls";
//            string[] fullname = { "ranga", "samy"};
//            string name1 = fname + " " + lname;
//            string name2 = string.Join("'grylls'", fullname);
//            Console.WriteLine("name 1 is " + name1);
//            Console.WriteLine("name 2 is " + name2);
// //Length and Compare    
//            if (string.Compare(fname, lname) == 0)
//            {
//                Console.WriteLine("the strings are same");
//            }
//            else
//            {
//                Console.WriteLine("the strings arent same");
//            }
//            if (fname.Length == lname.Length)
//            {
//                Console.WriteLine("both strings have same length");
//            }
//            else
//            {
//                Console.WriteLine("both strings have different length");
//            }
//            if (name2.Contains("ranga"))
//            {
//                Console.WriteLine("hi da ranga ");
//            }
//            string sub = name2.Substring(1);
//            Console.WriteLine(sub);
////Constant String   
//            const string cstr = "ranga loves potato";
//            //cstr = "ranga doesnt love potato";
//            Console.WriteLine(cstr);
////Verbatim 
//            string n1 = "hey \n ranga";
//            string n2 = @"hey \n ranga";
//            Console.WriteLine("string 1 is {0}\nstring 2 is {1}", n1, n2);
////Empty string length
//            string a = "a";
//            string b = null;
//            string c = "c";
//            string d = a + b + c;
//            string e = "";
//            Console.WriteLine("length of empty string " + e.Length);
//            Console.WriteLine(n1.CompareTo(n2));
// //Remove function
//            string ranga = "ranga grylls";
//            Console.WriteLine(ranga.Remove(1));// removes till the index in the bracket
// //Split function
//            string a5 = "ho.ho.ho.ha.ha.ha";
//            string[] a6 = a5.Split('.');
//            Console.WriteLine(a6[0]);
//            Console.WriteLine(a6[1]);
//            Console.WriteLine(a6[2]);
//            Console.WriteLine(a6[3]);
//            Console.WriteLine(a6[4]);
//        }
    }
}
