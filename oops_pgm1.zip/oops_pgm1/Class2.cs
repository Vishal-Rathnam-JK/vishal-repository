﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace oops_pgm1
{
    class Class2
    {
        //public static void Main()
        //{
        //    string[] dates=new String[5];
        //    for (int j = 0; j < 5; j++)
        //    {
        //        Console.WriteLine("enter the date");
        //        dates[j] = Console.ReadLine();
        //    }
           
        //    string[] format = { "dd-MMM-yyy", "dd/M/yyyy", "dd-MMMM-yyyy", "dd-MMM-yyyy" };
        //    string[] final = new string[5];
        //    DateTime dt;
        //    int i = 0;
        //    foreach (string item in dates)
        //    {
        //        bool b = DateTime.TryParseExact(item, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out dt);
        //        if (b == true)
        //        {
                    
        //            final[i] = dt.ToString("dd/MM/yyyy");
        //            i++;
        //        }
        //        else
        //        {
        //            Console.WriteLine("invalid date");
        //        }
        //    }
        //    List<string> li= final.Distinct().ToList();
        //    foreach (string item in li)
        //    {
        //        Console.WriteLine(item);
        //    }




        //}
    }  
}
