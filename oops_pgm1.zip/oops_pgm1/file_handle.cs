﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace oops_pgm1
{
    class file_handle
    {
        //public static void Main()
        //{
        //    //DriveInfo[] drive_info = DriveInfo.GetDrives();
        //    //foreach (DriveInfo item in drive_info)
        //    //{
        //    //    Console.WriteLine(item.Name);
        //    //   // Console.WriteLine(item.AvailableFreeSpace);
        //    //}
        //    //DirectoryInfo dir_info = new DirectoryInfo(@"D:\Vishal");
        //    //dir_info.Create();
        //    FileStream file_stream = new FileStream(@"D:\Vishal\demo.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
        //    //file_stream.Close();
        //    StreamWriter sw = new StreamWriter(file_stream);
        //    //sw.WriteLine("first line data");
        //    //sw.WriteLine("second line data");
        //    //sw.Close();
            
        //    string choice;
        //    do
        //    {
        //     Console.WriteLine("Enter the data");
        //     string s1 = Console.ReadLine();
        //     sw.WriteLine(s1);
        //     Console.WriteLine("do u want to enter further data : yes or no");            
        //     choice = Console.ReadLine();
        //    } while (choice=="yes");
        //    sw.Close();
        //}
    }
}
