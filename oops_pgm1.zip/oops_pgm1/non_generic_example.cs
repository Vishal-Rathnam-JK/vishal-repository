﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class non_generic_example
    {
        public void show(int data)
        {
            Console.WriteLine("the value is "+data);

        }
        public void show(string str)
        {
            Console.WriteLine("the value is "+str);
        }
        //public static void Main()
        //{
        //    non_generic_example nge = new non_generic_example();
        //    nge.show("hey");
        //    nge.show(2);
            
        //}
    }
}
