﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace oops_pgm1
{
    class collection_implementation
    {
        //public static void Main()
        //{
        //    ArrayList al = new ArrayList();
        //    Console.WriteLine(al.Count);
        //    al.Add("welcome");
        //    al.Add(20);
        //    al.Add(true);
        //    al.Add('A');
        //    al.Add("welcome");
        //    Console.WriteLine(al.Count);
        //    int x = 5 + (int)al[1];
        //    Console.WriteLine(x);
        //    Console.WriteLine(al[1]);
        //    Console.WriteLine(al[0]);
        //    //al.RemoveAt(1);
        //   // al.Remove("welcome");
        //   // al.Remove("welcome");
        //    Console.WriteLine(al.Count);
        //    foreach (var item in al)
        //    {
        //        Console.WriteLine(item);
        //        Console.WriteLine(item.GetType());
                
        //    }
        //    foreach (object item in al)
        //    {
        //        Console.WriteLine(item);
        //        Console.WriteLine(item.GetType());
        //    }
        //    
        //}
    }
}
