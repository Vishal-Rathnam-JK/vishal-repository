﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace oops_pgm1
//{
//    public abstract class mammal
//    {
//        public abstract void move();
//        //{
//        //    Console.WriteLine("Mammal");
//        //}
//    }
//    class human : mammal
//    {
//        public override void move()
//        {
//            Console.WriteLine("Human");
//        }
//    }
//    class whale : mammal
//    {
//        public override void move()
//        {
//            Console.WriteLine("Whale");
//        }
//    }
//    class f_override
//    {
//        public static void Main()
//        {
//            mammal m;

//            m = new human();
//            m.move();
//            m = new whale();
//            m.move();
//        }
//    }
//}
