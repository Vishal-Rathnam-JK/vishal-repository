﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace oops_pgm1
{
    class Sorted_list
    {
        //public static void Main()
        //{
        //    SortedList sl = new SortedList();
        //    sl.Add(1, "ranga");
        //    sl.Add(2, "vishal");
        //    ICollection ic = sl.Keys;
        //    foreach (int item in ic)
        //    {
        //        Console.WriteLine(sl[item]);
        //    }
        //}
    }
}
