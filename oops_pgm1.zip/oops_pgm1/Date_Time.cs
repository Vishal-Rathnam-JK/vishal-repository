﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Collections;


namespace oops_pgm1
{
    class Date_Time
    {
        //public static void Main()
        //{
        //    DateTime dt1 = new DateTime(1995, 02, 06);
        //    Console.WriteLine("The LEGEND was born on " + dt1.ToLongDateString());
        //    DateTime dt2 = new DateTime(1994, 11, 17);
        //    Console.WriteLine("The PISASU was born on " + dt2.ToString("dd-MM-yy"));
        //    Console.WriteLine("Enter the date as dd-MM-yyyy");
        //    string date = Console.ReadLine();
        //    string day = date.Substring(0, 2);
        //    string month = date.Substring(3, 2);
        //    string year = date.Substring(6, 4);
        //    if (int.Parse(day) <= 31 && int.Parse(month) <= 12)
        //    {
        //        Console.WriteLine("Its valid ");
        //        DateTime dt = new DateTime(int.Parse(year), int.Parse(month), int.Parse(day));
        //        Console.WriteLine("the date is " + dt.ToString("MMMM dd"));
        //        Console.WriteLine("the date is " + string.Format("{0:D}", dt));
        //        Console.WriteLine("the date is " + string.Format("{0:f}", dt));
        //        Console.WriteLine("the date is " + string.Format("{0:F}", dt));
        //        Console.WriteLine("the date is " + string.Format("{0:m}", dt));
        //        Console.WriteLine("the date is " + string.Format("{0:d}", dt));

        //    }
        //    else
        //    {
        //        Console.WriteLine("it's invalid");
        //    }

        //    DateTime d1;
        //    bool b = DateTime.TryParseExact(Console.ReadLine(), "dd/mm/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out d1);
        //    Console.WriteLine(d1);
        //}
    }
}
