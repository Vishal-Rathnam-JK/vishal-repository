﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class Class1
    {
        int p, q;
        public void accept(int i,int j)
        {
            p = i;
            q = j;
        }
        public void produce()
        {
            Console.WriteLine("the values are {0} and {1}",p,q);
        }
        //public static void Main()
        //{
        //    Class1 a = new Class1();
        //    a.accept(10, 20);
        //    a.produce();

        //}
    }
}
