﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace oops_pgm1
{
    class stack_implementaion
    {
        //public static void Main()
        //{
        //    Stack s = new Stack();
        //    s.Push("hi");
        //    s.Push("hey");
        //    s.Push(true);
        //    s.Push('A');
        //    int x = s.Count;
        //    Console.WriteLine("count="+x);
        //    object s1 = s.Pop();
        //    Console.WriteLine(s1);
        //    Console.WriteLine(s.Pop());
        //    x = s.Count;
        //    Console.WriteLine("count=" + x);
        //    Console.WriteLine(s.Peek());
        //    x = s.Count;
        //    Console.WriteLine("count=" + x);
        //    foreach (object o in s)
        //    {
        //        Console.WriteLine(o);
        //    }
        //}
    }
}
