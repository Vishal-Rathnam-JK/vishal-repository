﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class dictionary_example
    {
        //public static void Main()
        //{
        //    Dictionary<int, string> d = new Dictionary<int,string>();
        //    d.Add(1, "ranga");
        //    d.Add(2, "vishal");
        //    d.Add(3, "lavanya");
        //    Console.WriteLine("count is "+d.Count);
        //   // Console.WriteLine(d[2]);
        //    //foreach (KeyValuePair<int,string> item in d)
        //    //{
        //    //    Console.WriteLine(item);
        //    //    Console.WriteLine("the key is {0} , the value is {1}",item.Key,item.Value);
        //    //}
        //    List<int> l = new List<int>(d.Keys);
        //    foreach (int item in l)
        //    {
        //        Console.WriteLine(d[item]);
        //    }
        //    ICollection<int> ic = d.Keys;
        //    foreach (int item in ic)
        //    {
        //        Console.WriteLine(d[item]);
        //    }
        //}
        
    }
}
