﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    public abstract class shape
    {
      public abstract void area();
      public abstract void show();
            
       
   }
    class square:shape
    {
        int x;
        public override void area()
        {
           int a = 5;
           x=a*a;
        }
    //public int a = 5;
    // public int x=a*a;
 
        public override void show()
        {
            Console.WriteLine("the area is"+x);
        }
   
}
//class compute
//{
//    //public static void Main()
//    //{
//    //    shape s;
//    //    s = new square();
//    //    s.area();
//    //    s.show();
//    //}
    

//    }
}
