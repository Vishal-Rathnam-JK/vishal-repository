﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class Program:student
    {
       public int x;
        public int y;
        public  int z = 5;
        void accept()
        {
            x = 5;
            y = 8;
            add();
                   }
        void add()
        {
            int total = x + y;
            Console.WriteLine("The total is "+total);
        }
        //static void Main(string[] args)
        //{
        //    Program p = new Program();
           
        //    p.accept(5, 8);
        //  //p.add();
        //    student s = new student();
        //    p.store();
        //}
    }
    class student
    {
       protected int sid;
        public string sname;

        protected void store()
        {
            sid = 10;
            Program d = new Program();
            d.x = 8;
             Console.WriteLine(d.x);
            sname = "chn17id001";
        }
         protected void display()
        {
            Console.WriteLine("the student name is {0} , id is {1}",sname,sid);
        }
        //static void Main(string[] args)
        //{
        //   student s = new student();
           

        //}
    }
}
