﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class user_info
    {
       //public int UID
       //{
       //    get
       //    {
       //        return uid
       //    }
       //    set
       //{
       //    uid = value;
       //}
       //}
        public int UID { get; set; }
        public string UNAME { get; set; }
        public DateTime DOJ { get; set; }
        public user_info(int x ,string y, DateTime z)
    {
        UID = x;
        UNAME = y;
        DOJ = z;
    }
        //public static void Main()
        //{
            
        //}
    }
}
