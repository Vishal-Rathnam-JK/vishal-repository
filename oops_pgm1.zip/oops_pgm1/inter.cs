﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    interface i1
    {
        void method1();
     
        }
    class inter:i1
    {
        public void method1()
        {
            Console.WriteLine("hi");
        }
        //public static void Main()
        //{
        //    inter i = new inter();
        //    i.method1();
        //}
    }
}
