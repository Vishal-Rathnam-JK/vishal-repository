﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    //public delegate void show();
    //public delegate void addition(int var1, int var2);
    //class delegate_implementation
    //{
    //    public void multiply(int a, int b)
    //    {
    //        Console.WriteLine(a*b);
    //    }
    //    public void add(int x, int y)
    //    {
    //        Console.WriteLine(x+y);
    //    }
    //    public void show_output()
    //    {
    //        Console.WriteLine("This is from show output method");
    //    }
    //    public static void Main()
    //    {
    //        delegate_implementation del_obj = new delegate_implementation();
    //        //del_obj.show_output();
    //        show c1 = new show(del_obj.show_output);
    //        c1 = c1 + new show(del_obj.show_output);
    //        c1 += new show(del_obj.show_output);
    //        c1();
    //        addition comp1 = new addition(del_obj.add);
    //        comp1 += new addition(del_obj.multiply);
    //        comp1(5, 10);
    //        //addition comp2 = new addition(del_obj.multiply);
    //        //comp2(5, 10);
           
            
    //    }
   // }
}
