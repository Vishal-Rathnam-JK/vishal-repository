﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace oops_pgm1
{
    class file_handle2
    {
        //public static void Main()
        //{
        //    FileStream fs = new FileStream(@"D:\Vishal\demo.txt", FileMode.Open, FileAccess.Read);
        //    StreamReader sr = new StreamReader(fs);
        //    string sd;
        //    while ((sd = sr.ReadLine()) != null)
        //    {
        //        Console.WriteLine(sd);
        //    }
        //    //Console.WriteLine(sr.ReadToEnd());            
        //    sr.Close();
           
        //}
    }
}
