﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class number_replication
    {
        //public static void Main()
        //{
        //    int x = 3;
        //    int z = 0;
        //    for (int i = 0; i < 4; i++)
        //    {
        //        z = (z*10)+x;
        //        Console.WriteLine(z);
        //    }
        //}
    }
}
