﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class Function_Overloading
    {
        int add;
        int mul;
        //void calc(int a, int b)
        //{
        //    int x = a;
        //    int y = b;
        //     add = x + y;
        //     Console.WriteLine("addition is "+add);
        //}
        //void calc(int a, int b,int c)
        //{
        //    int x = a;
        //    int y = b;
        //   int z = c;
        //    mul = x * y * z ;
        //    Console.WriteLine("product is " +mul);
        //}
        int calc(int a, int b)
        {
            int x = a;
            int y = b;
             add = x + y;
           // Console.WriteLine("addition is " + add);
            return (add);
        }
        int calc(int a, int b, int c)
        {
            int x = a;
            int y = b;
            int z = c;
           mul = x * y * z;
          //  Console.WriteLine("product is " + mul);
            return (mul);
        }
        //public static void Main()
        //{
        //    Function_Overloading c = new Function_Overloading();
        //  int a= c.calc(5,5);
        //   int b=c.calc(2, 3, 4);
        //    Console.WriteLine("sum is {0} product is {1}",a,b);
        //}
    }
}
