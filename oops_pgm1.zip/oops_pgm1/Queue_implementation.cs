﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace oops_pgm1
{
    class Queue_implementation
    {
        //public static void Main()
        //{
        //    Queue q = new Queue();
        //    q.Enqueue("hi");
        //    q.Enqueue(1);
        //    q.Enqueue("hey");
        //    foreach (object item in q)
        //    {
        //        Console.WriteLine(item);
        //    }
        //    Console.WriteLine("count=" + q.Count);
        //    Console.WriteLine(q.Dequeue()+" is removed");
        //    Console.WriteLine("count="+q.Count);
        //}
    }
}
