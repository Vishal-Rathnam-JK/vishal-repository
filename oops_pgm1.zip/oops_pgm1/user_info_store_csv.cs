﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Globalization;

namespace oops_pgm1
{
    class user_info_store_csv
    {
        List<user_info> users;
        public user_info_store_csv()
        {
            users = new List<user_info>();
        }
        public void storedata()
        {
            if (users==null)
            {
             // users = new users()  
            }
            Console.WriteLine("enter the user details");
            Console.WriteLine("enter the user id");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("enter the user name");
            string name = Console.ReadLine();
            DateTime doj;
            while (1 == 1)
            {
                Console.WriteLine("enter the date of joining as dd/mm/yyyy");
                string data = Console.ReadLine();                
                bool b = DateTime.TryParseExact(data, "d/M/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out doj);
                if (b == false)
                {
                    Console.WriteLine("invalid date");
                }
                else
                {
                    break;
                }
            }
            //users.Add(new user_info(id,name,doj));
            user_info ui = new user_info(id, name, doj);
            users.Add(ui);

        }
        public void save()
        {
            FileStream fs;
            StreamWriter sw;
            if (!File.Exists(@"D:\Vishal\user.csv"))
            {
                fs = new FileStream(@"D:\Vishal\user.csv", FileMode.CreateNew, FileAccess.Write);
                sw = new StreamWriter(fs);
                sw.WriteLine("uid,uname,doj");
            }
            else
            {
                fs = new FileStream(@"D:\Vishal\user.csv", FileMode.Append, FileAccess.Write);
                sw = new StreamWriter(fs);
            }
            foreach (user_info u in users)
            {
                string[] values = new string[3] { u.UID.ToString(), u.UNAME, u.DOJ.ToString("dd/mm/yyyy") };
                string lastdata = string.Join(",", values);
                sw.WriteLine(lastdata);
            }
            sw.Close();
            users = null;
        }
        //public static void Main()
        //{
        //    user_info_store_csv scv = new user_info_store_csv();            
        //    scv.storedata();
        //    user_info_store_csv scv2 = new user_info_store_csv();
        //    scv2.storedata();
        //}
    }
}
