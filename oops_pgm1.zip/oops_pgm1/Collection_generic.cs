﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class emp
    {
       public int eid;
       public string ename;
       public double salary;
    }
    class Collection_generic
    {
        //public static void Main()
        //{
        //    List<int> li = new List<int>();
        //    li.Add(420);
        //    li.Add(12);
        //    li.Add(56);
        //    li.Add(32);
        //    li.Add(42);
        //    Console.WriteLine("count is "+li.Count);
        //    foreach (int item in li)
        //    {
        //        Console.WriteLine(item);
        //    }
        //    emp e1 = new emp();
        //    e1.eid = 1;
        //    e1.ename="Vishal";
        //    e1.salary=2424.2342;
        //    emp e2 = new emp();
        //    e2.eid = 2;
        //    e2.ename = "Ranga";
        //    e2.salary = 24564.342;
        //    emp e3 = new emp();
        //    e3.eid = 3;
        //    e3.ename = "Lavanya";
        //    e3.salary = 516.20;
        //    List<emp> emplist = new List<emp>();
        //    emplist.Add(e1);
        //    emplist.Add(e2);
        //    emplist.Add(e3);
        //    foreach (emp e in emplist)
        //    {
        //        Console.WriteLine("the eid is {0} name is {1} salary is {2}",e.eid,e.ename,e.salary);
        //    }
            

        //}
    }
}
