﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class user_defined
    {
      //Console.WriteLine("enter the age");
      //  public    int age = int.Parse(Console.ReadLine());
        public int age;
       public  void verifyage()
        {
            if (age < 18)
            {
                throw new voting();
            }
            else
            {
                Console.WriteLine("valid age");
            }
        }
        
    }
     class voting : Exception
    {
        public string displayerror()
    {
        return "you're not eligible for voting";
    }
        // public static void Main()
        //{
        //    user_defined ud = new user_defined();
        //    ud.age = 16;
        //    try
        //    {
        //        ud.verifyage();
        //    }
        //    catch (voting v)
        //    {

        //        Console.WriteLine(v.displayerror());
        //    }
             
        //}
    }
}
