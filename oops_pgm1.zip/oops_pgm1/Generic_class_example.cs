﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class Generic_class_example<U,T>
    {
      //  public U data1;
       // public T data2;
       // public Generic_class_example(U data1)
       // {
           

       // }
      //  public void display()
       // {
        //    Console.WriteLine("the output is "+data1+"   " +data2);
        //}
    }
    class gce
    {
        //public static void Main()
        //{
        //   Generic_class_example <int,string>gc1 = new Generic_class_example<int,string>();
        //   gc1.data1 = 23;
        //   gc1.data2 = "ranga";
        //    gc1.display();
        //   //Generic_class_example<string> gc2 = new Generic_class_example<string>("hey");
        //   //gc2.display();
           
        //}
    }
}
