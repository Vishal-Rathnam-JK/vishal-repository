﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class static_eg
    {
        static int info;
        public int a;
        public void change()
        {
            info++;
            a++;             
        }
        void display()
        {
            Console.WriteLine("info ="+info);
            Console.WriteLine("a ="+a);
        }
        //public static void Main()
        //{
        //    static_eg s1,s2;
        //    s1 = new static_eg();
        //    s2 = new static_eg();
        //    s1.change();
        //    s1.display();
        //    static_eg.info = 3;
        //    s2.display();
        //    s2.change();
        //    s2.display();
        //    static_eg.info = 5;
        //    s2.display();
        //}
    }       
}
