﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class decimal_seperation
    {
        //public static void Main()
        //{
        //    double over = 14.1;
            
        //    var wicket = 45;
        //    string[] parts = Convert.ToString(over).Split('.');
        //    Console.WriteLine(parts[0]);
        //    Console.WriteLine(parts[1]);
        //    float i1 = int.Parse(parts[0]);
        //    float i2 = int.Parse(parts[1]);
        //    Console.WriteLine(i1);
        //    Console.WriteLine(i2);
        //    var balls = i1 * 6 + i2;
        //    Console.WriteLine(balls);
        //    var rate = balls / wicket;
        //    Console.WriteLine(rate);
        //    
        //    
       // }
    }
}
