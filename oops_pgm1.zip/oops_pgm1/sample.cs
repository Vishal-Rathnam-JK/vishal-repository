﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class sample
    {
        public static void Main()
        {
            int[] ar = { 1, 3, 2, 4, 5, 6 };
            //foreach (int item in ar)
            //{
                
            //}
            Console.WriteLine(3%2);
        }
    }
}
