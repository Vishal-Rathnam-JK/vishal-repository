﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oops_pgm1
{
    class array_types
    {
        //public static void Main()
        //{
        //    //1d array
        //    int[] onearr = { 10, 05, 30, 25 };
        //    Console.WriteLine("length of array is {0}\nLower bound is {1}\nUpper bound is {2}", onearr.Length,
        //        onearr.GetLowerBound(0), onearr.GetUpperBound(0));
        //    ////2d array
        //    int[,] twoarr = new int[3, 2];
        //    for (int i = 0; i <= twoarr.GetUpperBound(0); i++)
        //    {
        //        for (int j = 0; j <= twoarr.GetUpperBound(1); j++)
        //        {
        //            Console.WriteLine("enter the{0},{1} element", i, j);
        //            twoarr[i, j] = int.Parse(Console.ReadLine());
        //        }
        //    }
        //    for (int i = 0; i < twoarr.GetLength(0); i++)
        //    {
        //        Console.WriteLine("\n");
        //        for (int j = 0; j < twoarr.GetLength(1); j++)
        //        {
        //            Console.Write(twoarr[i, j]);
        //        }
        //    }
        //    //using foreach
        //    foreach (int i in twoarr)
        //    {
        //        Console.WriteLine(i);
        //    }
        //    //3d array
        //    int[, ,] threearr = new int[3, 4, 2]{{{3,2},{1,4},{5,6},{7,8}},
        //                                       {{9,10},{11,12},{13,14},{15,16}},
        //                                       {{17,18},{19,20},{21,22},{23,24}}};
        //    foreach (int item in threearr)
        //    {
        //        Console.WriteLine(item);
        //    }
        //    //array sort           
        //    Array.Sort(onearr, 0, 2);// (array name , start index , LENGTH) 
        //    foreach (int item in onearr)
        //    {
        //        Console.WriteLine(item);
        //    }
        //    int[] keys = new int[5] { 5, 4, 3, 2, 1 };
        //    int[] values = new int[5] { 1, 2, 3, 4, 5 };
        //    Array.Sort(keys, values);
        //    foreach (int item in keys)
        //    {
        //        Console.WriteLine(item);
        //    }
        //    foreach (int item in values)
        //    {
        //        Console.WriteLine(item);
        //    }
        //    //jagged array
        //    int[][] jagarr = new int[3][];
        //    jagarr[0] = new int[6] { 1, 23, 34, 1, 1, 1 };
        //    jagarr[1] = new int[3] { 2, 3, 4 };
        //    jagarr[2] = new int[4] { 5, 5, 6, 2 };
        //    foreach (int[] item in jagarr)
        //    {
        //        foreach (int abc in item)
        //        {
        //            Console.WriteLine(abc);
        //        }

        //    }
        //}
        

    }
}
